<?php
require 'InitializationData.php';
// base class with member properties and methods
class ProcessSelection extends InitializationData
{

    public $initializationData;
    private $arrResultFunc = [];
    //var $listsekolah = [];

    public function __construct()
    {
        $this->initializationData = new InitializationData;
    }

    public function sorting(&$arr, $col_total, $col_total2, $col_n1, $col_n2, $col_n3, $col_n4, $col_skorjarak)
    {
        $sort_col_total     = array();
        $sort_col_total2    = array();
        $sort_col_n1        = array();
        $sort_col_n2        = array();
        $sort_col_n3        = array();
        $sort_col_n4        = array();
        $sort_col_skorjarak = array();

        foreach ($arr as $key => $row) {
            $sort_col_total[$key]     = $row[$col_total];
            $sort_col_total2[$key]    = $row[$col_total2];
            $sort_col_n1[$key]        = $row[$col_n1];
            $sort_col_n2[$key]        = $row[$col_n2];
            $sort_col_n3[$key]        = $row[$col_n3];
            $sort_col_n4[$key]        = $row[$col_n4];
            $sort_col_skorjarak[$key] = $row[$col_skorjarak];
        }
        array_multisort($sort_col_total, SORT_DESC, $sort_col_total2, SORT_DESC, $sort_col_n1, SORT_DESC, $sort_col_n2, SORT_DESC, $sort_col_n3, SORT_DESC, $sort_col_n4, SORT_DESC, $sort_col_skorjarak, SORT_DESC, $arr);
    }

    public function processDataSelection($listsekolahsmk)
    {

        $passgrad = true;
        while ($passgrad != false) {
            // selama masih ada sekolah yg harus di sorting
            $passgrad = false;

            foreach ($listsekolahsmk as $sekolah) {
                // sort tiap sekolah
                if ($sekolah['id'] == '9999') {continue;}
                if ($sekolah['status'] == 0) {
                    # init
                    $id = $sekolah['id'];

                    # sort
                    $this->sorting($listsekolahsmk[$id]['data'], 'total', 'total2', 'score_bahasa', 'score_english', 'score_math', 'score_physics', 'score_range');
                    // print_r($listsekolahsmk[$id]['data']);
                    // echo '<br>';

                    # passing
                    $jml_pend = count($listsekolahsmk[$id]['data']);

                    if ($jml_pend > $sekolah['quota']) {
                        /* potong berdasarkan quota */

                        // # lemparkan
                        for ($i = $jml_pend - 1; $i > $sekolah['quota'] - 1; $i--) {
                            if ($listsekolahsmk[$id]['data'][$i]['second_choice'] != $sekolah['id']) {
                                /* lempar ke pilihan 2 */

                                $listsekolahsmk[$id]['data'][$i]['total']       = $listsekolahsmk[$id]['data'][$i]['total2']; /*lempar ke pilihan 2, total diganti ke total2*/
                                $listsekolahsmk[$id]['data'][$i]['score_range'] = $listsekolahsmk[$id]['data'][$i]['score_range2']; /*lempar ke pilihan 2, skor jarak diganti ke skor jarak2*/

                                if ($listsekolahsmk[$id]['data'][$i]['second_choice'] == 9999) {
                                    $listsekolahsmk[$id]['data'][$i]['accepted_status'] = 3;
                                    $listsekolahsmk[$id]['data'][$i]['accepted_school'] = 9999;

                                    array_push($listsekolahsmk['9999']['data'], $listsekolahsmk[$id]['data'][$i]);
                                    array_splice($listsekolahsmk[$id]['data'], $i, 1);

                                } else {

                                    $xid = $listsekolahsmk[$id]['data'][$i]['second_choice']; //cek id sekolah
                                    if (!isset($listsekolahsmk[$xid])) {
                                        //cek id sekolah, jika tidak ada lempar ke pilihan 9999
                                        echo 'id sekolah tidak ada = ' . $xid . '<br/>';
                                        $listsekolahsmk[$id]['data'][$i]['accepted_status'] = 3;
                                        $listsekolahsmk[$id]['data'][$i]['accepted_school'] = 9999;
                                        array_push($listsekolahsmk['9999']['data'], $listsekolahsmk[$id]['data'][$i]);
                                        array_splice($listsekolahsmk[$id]['data'], $i, 1);
                                    } else {
                                        $listsekolahsmk[$id]['data'][$i]['accepted_status']                          = 2;
                                        $listsekolahsmk[$id]['data'][$i]['accepted_school']                          = $listsekolahsmk[$id]['data'][$i]['second_choice'];
                                        $listsekolahsmk[$listsekolahsmk[$id]['data'][$i]['second_choice']]['status'] = 0;
                                        array_push($listsekolahsmk[$listsekolahsmk[$id]['data'][$i]['second_choice']]['data'], $listsekolahsmk[$id]['data'][$i]);
                                        array_splice($listsekolahsmk[$id]['data'], $i, 1);
                                    }

                                }
                            } else {
                                // tidak accepted_status dimana2
                                $listsekolahsmk[$id]['data'][$i]['accepted_status'] = 3;
                                $listsekolahsmk[$id]['data'][$i]['accepted_school'] = 9999;
                                array_push($listsekolahsmk['9999']['data'], $listsekolahsmk[$id]['data'][$i]);
                                array_splice($listsekolahsmk[$id]['data'], $i, 1);
                            }
                        }
                    }
                    $listsekolahsmk[$id]['status'] = 1;

                }
            }

            # cek sekolah, bisi aya nu can di sorting
            foreach ($listsekolahsmk as $sekolah) {
                if ($sekolah['status'] == 0) {
                    $passgrad = true;
                    break;
                }
            }
        }

        return $listsekolahsmk;

    } //endfunction processDataSelection

    public function setProcessData()
    {
        $listsekolah = [];
        $listsekolah = $this->initializationData->getSchool();
        $listsekolah = $this->processDataSelection($listsekolah);
        return $listsekolah;
    }

} // end of class Vegetable
