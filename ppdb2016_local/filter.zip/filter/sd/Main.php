<?php
require 'ViewData.php';

$viewData = new ViewData;
$viewData->showDataAll();

?>