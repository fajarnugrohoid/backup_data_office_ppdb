<?php
require 'InitializationData.php';
// base class with member properties and methods
class ProcessSelection extends InitializationData
{

    public $initializationData;
    private $arrResultFunc = [];
    //var $listsekolah = [];

    public function __construct()
    {
        $this->initializationData = new InitializationData;
    }

    public function sorting(&$arr, $col_score_age, $col_skorjarak, $col_range)
    {
        $sort_col_score_age = array();
        $sort_col_skorjarak = array();
        $sort_col_range     = array();

        foreach ($arr as $key => $row) {
            $sort_col_score_age[$key] = $row[$col_score_age];
            $sort_col_skorjarak[$key] = $row[$col_skorjarak];
            $sort_col_range[$key]     = $row[$col_range];

        }
        array_multisort($sort_col_score_age, SORT_DESC, $sort_col_skorjarak, SORT_DESC, $sort_col_range, SORT_ASC, $arr);
    }

    public function initQuota($listsekolah)
    {
        /* Init quota dan Cek quota*/
        #------- Proses
        foreach ($listsekolah as $sekolah) {

            echo $sekolah['id'] . '-' . $sekolah['quota'] . '<br/>';

            $kuota_seluruh = (int) $sekolah['quota'];
            $persentase    = (int) $sekolah['foreigner_percentage'];
            $kuota_luar    = floor($kuota_seluruh * $persentase / 100);
            $kuota_dalam   = $kuota_seluruh - $kuota_luar;

            $listsekolah[$sekolah['id']]['dalam']['quota'] = $kuota_dalam;
            $listsekolah[$sekolah['id']]['luar']['quota']  = $kuota_luar;

            echo 'kuota dalam : ' . $listsekolah[$sekolah['id']]['dalam']['quota'] . '-';
            echo 'quota luar : ' . $listsekolah[$sekolah['id']]['luar']['quota'] . '<br/>';

            $t_pendaftar_dalam = count($listsekolah[$sekolah['id']]['dalam']['data']);
            $t_pendaftar_luar  = count($listsekolah[$sekolah['id']]['luar']['data']);

            if ($kuota_luar > $t_pendaftar_luar) {
                $selisih                                       = $kuota_luar - $t_pendaftar_luar;
                $listsekolah[$sekolah['id']]['dalam']['quota'] = $kuota_dalam + $selisih;
                $listsekolah[$sekolah['id']]['luar']['quota']  = $kuota_luar - $selisih;
            }

            echo 'pend dalam : ' . $t_pendaftar_dalam . '-';
            echo 'pend luar : ' . $t_pendaftar_luar . '<br/>';
            echo 'sesudah<br/>dalam : ' . $listsekolah[$sekolah['id']]['dalam']['quota'] . '-';
            echo 'luar : ' . $listsekolah[$sekolah['id']]['luar']['quota'];

            echo '<br/><br/>';
        }
        return $listsekolah;
    }

    public function processDataSelection($listsekolah)
    {

        #------- Proses dalam
        $passgrad = true;
        while ($passgrad != false) {
            // selama masih ada sekolah yg harus di sorting
            $passgrad = false;

            foreach ($listsekolah as $sekolah) {
                // sort tiap sekolah
                if ($sekolah['id'] == '9999') {continue;}
                if ($sekolah['dalam']['status'] == 0) {
                    # init
                    $id = $sekolah['id'];

                    # sort
                    $this->sorting($listsekolah[$id]['dalam']['data'], 'score_age', 'score_range', 'range');
                    // print_r($listsekolah[$id]['data']);
                    // echo '<br>';

                    # passing
                    $jml_pend = count($listsekolah[$id]['dalam']['data']);

                    if ($jml_pend > $listsekolah[$id]['dalam']['quota']) {
                        /* potong berdasarkan quota */
                        // # lemparkan
                        for ($i = $jml_pend - 1; $i > $sekolah['dalam']['quota'] - 1; $i--) {
                            if ($listsekolah[$id]['dalam']['data'][$i]['second_choice'] != $sekolah['id']) {
                                /* lempar ke pilihan 2 */

                                $listsekolah[$id]['dalam']['data'][$i]['score_range'] = $listsekolah[$id]['dalam']['data'][$i]['score_range2']; /*lempar ke pilihan 2, skor jarak diganti ke skor jarak2*/
                                $listsekolah[$id]['dalam']['data'][$i]['range']       = $listsekolah[$id]['dalam']['data'][$i]['range2']; /*lempar ke pilihan 2, skor jarak diganti ke range*/

                                if ($listsekolah[$id]['dalam']['data'][$i]['second_choice'] == 9999) {
                                    $listsekolah[$id]['dalam']['data'][$i]['accepted_status'] = 3;
                                    $listsekolah[$id]['dalam']['data'][$i]['accepted_school'] = 9999;

                                    array_push($listsekolah['9999']['dalam']['data'], $listsekolah[$id]['dalam']['data'][$i]);
                                    array_splice($listsekolah[$id]['dalam']['data'], $i, 1);

                                } else {

                                    //cek id sekolah
                                    $xid = $listsekolah[$id]['dalam']['data'][$i]['second_choice'];
                                    if (!isset($listsekolah[$xid])) {
                                        //jika tidak ada, maka lempar ke pilihan 9999
                                        $listsekolah[$id]['dalam']['data'][$i]['accepted_status'] = 3;
                                        $listsekolah[$id]['dalam']['data'][$i]['accepted_school'] = 9999;
                                        array_push($listsekolah['9999']['dalam']['data'], $listsekolah[$id]['dalam']['data'][$i]);
                                        array_splice($listsekolah[$id]['dalam']['data'], $i, 1);
                                    } else {
                                        $listsekolah[$id]['dalam']['data'][$i]['accepted_status']                                = 2;
                                        $listsekolah[$id]['dalam']['data'][$i]['accepted_school']                                = $listsekolah[$id]['dalam']['data'][$i]['second_choice'];
                                        $listsekolah[$listsekolah[$id]['dalam']['data'][$i]['second_choice']]['dalam']['status'] = 0;
                                        array_push($listsekolah[$listsekolah[$id]['dalam']['data'][$i]['second_choice']]['dalam']['data'], $listsekolah[$id]['dalam']['data'][$i]);
                                        array_splice($listsekolah[$id]['dalam']['data'], $i, 1);
                                    }
                                }
                            } else {
                                // tidak accepted_status dimana2
                                $listsekolah[$id]['dalam']['data'][$i]['accepted_status'] = 3;
                                $listsekolah[$id]['dalam']['data'][$i]['accepted_school'] = 9999;
                                array_push($listsekolah['9999']['dalam']['data'], $listsekolah[$id]['dalam']['data'][$i]);
                                array_splice($listsekolah[$id]['dalam']['data'], $i, 1);
                            }
                        }
                    }
                    $listsekolah[$id]['dalam']['status'] = 1;

                }
            }

            # cek sekolah, bisi aya nu can di sorting
            foreach ($listsekolah as $sekolah) {
                if ($sekolah['dalam']['status'] == 0) {
                    $passgrad = true;
                    break;
                }
            }
        }

        return $listsekolah;

    } //endfunction processDataGW

    public function processDataLuarKota($listsekolah)
    {
        // $this->listsekolah=$this->initializationData->getSchool();
        #------- Proses luar kota

        #------- Proses luar
        $passgrad = true;
        while ($passgrad != false) {
            // selama masih ada sekolah yg harus di sorting
            $passgrad = false;

            foreach ($listsekolah as $sekolah) {
                // sort tiap sekolah
                if ($sekolah['id'] == '9999') {continue;}
                if ($sekolah['luar']['status'] == 0) {
                    # init
                    $id = $sekolah['id'];

                    # sort
                    $this->sorting($listsekolah[$id]['luar']['data'], 'score_age', 'score_range', 'range');
                    // print_r($listsekolah[$id]['data']);
                    // echo '<br>';

                    # passing
                    $jml_pend = count($listsekolah[$id]['luar']['data']);
                    //echo $sekolah['id'] . '--' . $jml_pend . '-'. $listsekolah[$id]['luar']['quota'] . '<br/>';

                    if ($jml_pend > $listsekolah[$id]['luar']['quota']) {
                        /* potong berdasarkan quota */
                        // # lemparkan
                        for ($i = $jml_pend - 1; $i > $sekolah['luar']['quota'] - 1; $i--) {
                            if ($listsekolah[$id]['luar']['data'][$i]['second_choice'] != $sekolah['id']) {
                                /* lempar ke pilihan 2 */

                                $listsekolah[$id]['luar']['data'][$i]['score_range'] = $listsekolah[$id]['luar']['data'][$i]['score_range2']; /*lempar ke pilihan 2, skor jarak diganti ke skor jarak2*/
                                $listsekolah[$id]['luar']['data'][$i]['range']       = $listsekolah[$id]['luar']['data'][$i]['range2']; /*lempar ke pilihan 2, skor jarak diganti ke skor jarak2*/

                                if ($listsekolah[$id]['luar']['data'][$i]['second_choice'] == 9999) {
                                    $listsekolah[$id]['luar']['data'][$i]['accepted_status'] = 3;
                                    $listsekolah[$id]['luar']['data'][$i]['accepted_school'] = 9999;

                                    array_push($listsekolah['9999']['luar']['data'], $listsekolah[$id]['luar']['data'][$i]);
                                    array_splice($listsekolah[$id]['luar']['data'], $i, 1);

                                } else {

                                    //cek id sekolah
                                    $xid = $listsekolah[$id]['luar']['data'][$i]['second_choice'];
                                    if (!isset($listsekolah[$xid])) {
                                        //jika tidak ada, maka lempar ke pilihan 9999
                                        $listsekolah[$id]['luar']['data'][$i]['accepted_status'] = 3;
                                        $listsekolah[$id]['luar']['data'][$i]['accepted_school'] = 9999;
                                        array_push($listsekolah['9999']['luar']['data'], $listsekolah[$id]['luar']['data'][$i]);
                                        array_splice($listsekolah[$id]['luar']['data'], $i, 1);
                                    } else {
                                        $listsekolah[$id]['luar']['data'][$i]['accepted_status']                               = 2;
                                        $listsekolah[$id]['luar']['data'][$i]['accepted_school']                               = $listsekolah[$id]['luar']['data'][$i]['second_choice'];
                                        $listsekolah[$listsekolah[$id]['luar']['data'][$i]['second_choice']]['luar']['status'] = 0;
                                        array_push($listsekolah[$listsekolah[$id]['luar']['data'][$i]['second_choice']]['luar']['data'], $listsekolah[$id]['luar']['data'][$i]);
                                        array_splice($listsekolah[$id]['luar']['data'], $i, 1);
                                    }
                                }
                            } else {
                                // tidak accepted_status dimana2
                                $listsekolah[$id]['luar']['data'][$i]['accepted_status'] = 3;
                                $listsekolah[$id]['luar']['data'][$i]['accepted_school'] = 9999;
                                array_push($listsekolah['9999']['luar']['data'], $listsekolah[$id]['luar']['data'][$i]);
                                array_splice($listsekolah[$id]['luar']['data'], $i, 1);
                            }
                        }
                    }
                    $listsekolah[$id]['luar']['status'] = 1;

                }
            }

            # cek sekolah, bisi aya nu can di sorting
            foreach ($listsekolah as $sekolah) {
                if ($sekolah['luar']['status'] == 0) {
                    $passgrad = true;
                    break;
                }
            }
        }

        return $listsekolah;

    } //end of process Datas

    public function processDataSelectionAll($listsekolah)
    {

        #-------seleksi tanpa 10% luar kota, semua masuk
        $passgrad = true;
        while ($passgrad != false) {
            // selama masih ada sekolah yg harus di sorting
            $passgrad = false;

            foreach ($listsekolah as $sekolah) {
                // sort tiap sekolah
                if ($sekolah['id'] == '9999') {continue;}
                if ($sekolah['status'] == 0) {
                    # init
                    $id = $sekolah['id'];

                    # sort
                    $this->sorting($listsekolah[$id]['data'], 'score_age', 'score_range', 'range');
                    // print_r($listsekolah[$id]['data']);
                    // echo '<br>';

                    # passing
                    $jml_pend = count($listsekolah[$id]['data']);

                    if ($jml_pend > $listsekolah[$id]['quota']) {
                        /* potong berdasarkan quota */
                        // # lemparkan
                        for ($i = $jml_pend - 1; $i > $sekolah['quota'] - 1; $i--) {
                            if ($listsekolah[$id]['data'][$i]['second_choice'] != $sekolah['id']) {
                                /* lempar ke pilihan 2 */

                                $listsekolah[$id]['data'][$i]['score_range'] = $listsekolah[$id]['data'][$i]['score_range2']; /*lempar ke pilihan 2, skor jarak diganti ke skor jarak2*/
                                $listsekolah[$id]['data'][$i]['range']       = $listsekolah[$id]['data'][$i]['range2']; /*lempar ke pilihan 2, skor jarak diganti ke range*/

                                if ($listsekolah[$id]['data'][$i]['second_choice'] == 9999) {
                                    $listsekolah[$id]['data'][$i]['accepted_status'] = 3;
                                    $listsekolah[$id]['data'][$i]['accepted_school'] = 9999;

                                    array_push($listsekolah['9999']['data'], $listsekolah[$id]['data'][$i]);
                                    array_splice($listsekolah[$id]['data'], $i, 1);

                                } else {

                                    //cek id sekolah
                                    $xid = $listsekolah[$id]['data'][$i]['second_choice'];
                                    if (!isset($listsekolah[$xid])) {
                                        //jika tidak ada, maka lempar ke pilihan 9999
                                        $listsekolah[$id]['data'][$i]['accepted_status'] = 3;
                                        $listsekolah[$id]['data'][$i]['accepted_school'] = 9999;
                                        array_push($listsekolah['9999']['data'], $listsekolah[$id]['data'][$i]);
                                        array_splice($listsekolah[$id]['data'], $i, 1);
                                    } else {
                                        $listsekolah[$id]['data'][$i]['accepted_status']                       = 2;
                                        $listsekolah[$id]['data'][$i]['accepted_school']                       = $listsekolah[$id]['data'][$i]['second_choice'];
                                        $listsekolah[$listsekolah[$id]['data'][$i]['second_choice']]['status'] = 0;
                                        array_push($listsekolah[$listsekolah[$id]['data'][$i]['second_choice']]['data'], $listsekolah[$id]['data'][$i]);
                                        array_splice($listsekolah[$id]['data'], $i, 1);
                                    }
                                }
                            } else {
                                // tidak accepted_status dimana2
                                $listsekolah[$id]['data'][$i]['accepted_status'] = 3;
                                $listsekolah[$id]['data'][$i]['accepted_school'] = 9999;
                                array_push($listsekolah['9999']['data'], $listsekolah[$id]['data'][$i]);
                                array_splice($listsekolah[$id]['data'], $i, 1);
                            }
                        }
                    }
                    $listsekolah[$id]['status'] = 1;

                }
            }

            # cek sekolah, bisi aya nu can di sorting

            foreach ($listsekolah as $sekolah) {

                //print_r($sekolah);echo "<br/><br/>";
                //exit();
                if ($sekolah['status'] == 0) {
                    $passgrad = true;
                    break;
                }
            }
        }

        return $listsekolah;

    } //endfunction processDataGW

    public function setProcessData()
    {
        $listsekolah = [];
        /*$listsekolah = $this->initializationData->getSchool();
        $listsekolah = $this->initQuota($listsekolah);
        $listsekolah = $this->processDataSelection($listsekolah);
        $listsekolah = $this->processDataLuarKota($listsekolah); */
        
        $listsekolah = $this->initializationData->getSchoolJoinDalamKotaLuarKota();
        $listsekolah = $this->processDataSelectionAll($listsekolah);
        return $listsekolah;
    }

} // end of class
