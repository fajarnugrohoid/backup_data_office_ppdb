<?php
/**
Plugin Name: STM Vehicles Listing
Plugin URI: http://stylemixthemes.com/
Description: STM Vehicles Listing
Author: StylemixThemes
Author URI: http://stylemixthemes.com/
Text Domain: stm_vehicles_listing
Version: 4.1
 */

define( 'STM_LISTINGS_PATH', dirname( __FILE__ ) );
define( 'STM_LISTINGS_URL', plugins_url( '', __FILE__ ) );
define( 'STM_LISTINGS', 'stm_vehicles_listing' );

define( 'STM_LISTINGS_IMAGES', STM_LISTINGS_URL . '/includes/admin/butterbean/images/' );

if ( ! is_textdomain_loaded( 'stm_vehicles_listing' ) ) {
	load_plugin_textdomain( 'stm_vehicles_listing', false, 'stm_vehicles_listing/languages' );
}

require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/query.php';

//todo move to functions.php
require_once __DIR__ . '/includes/options.php';
require_once __DIR__ . '/includes/actions.php';

if ( is_admin() ) {
    require_once __DIR__ . '/includes/admin/categories.php';
    require_once __DIR__ . '/includes/admin/enqueue.php';
    require_once __DIR__ . '/includes/admin/butterbean_metaboxes.php';

    //todo move from wp_options to term_meta
    require_once __DIR__ . '/includes/admin/category-image.php';
	require_once __DIR__ . '/includes/automanager/xml-importer-automanager.php';
	require_once __DIR__ . '/includes/automanager/xml-importer-automanager-ajax.php';
	require_once __DIR__ . '/includes/automanager/xml-importer-automanager-iframe.php';
	require_once __DIR__ . '/includes/automanager/xml-importer-automanager-cron.php';
}