<?php get_header();?>

	<?php get_template_part('partials/title_box'); ?>

	<?php stm_listings_load_template('filter/inventory/main'); ?>

<?php get_footer();