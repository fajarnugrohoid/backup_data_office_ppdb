<div class="title heading-font">
	<a href="<?php the_permalink() ?>" class="rmv_txt_drctn">
		<?php the_title(); ?>
	</a>
</div>