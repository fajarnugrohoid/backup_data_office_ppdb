<?php
ini_set('memory_limit', '1024M');
//require 'ViewData.php';
require 'ViewData.php';


$viewData = new ViewData;
$viewData->showData();

/*$InitializationData = new InitializationData;
$listschool=$InitializationData->getSchool();*/

?>